<?php


function formatTrasactionCode($code){

	return number_format($code);

}