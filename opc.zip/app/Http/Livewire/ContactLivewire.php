<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ContactLivewire extends Component
{
    public function render()
    {
    	
        return view('livewire.contact-livewire');
    }
}
