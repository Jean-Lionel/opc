<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>JEAN LIONEL</title>
</head>
<body>

	<h1>MESSAGE DE CONFIRMATION DE L'OPC BURUNDI</h1>
	<p>{{  $details['body']}}</p>

	<p>Nom d'utilisateur : {{$details['user_name']}}</p>
	<p>Mot de pass est  : {{$details['password']}}</p>
	<p>{{$details['body']}}</p>
	<p>Thank you</p>
	
</body>
</html>