@extends('layouts.base')

@section('content')

<div>
	<livewire:user-profil />
	
</div>


@endsection