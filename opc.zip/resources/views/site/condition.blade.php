@include('site.header',['title'=> "Condition d'adhésion dans l'OPC"])
<div class="container mt-3">

	<div class="col-md-10 offset-2">
		<h4>CONDITIONS  D’ACCES  AUX  DIFFERENTS  TABLEAUX  DE L’ORDRE DES PROFESSIONNELS COMPTABLES</h4>

		<p class="text-center ml-2" >
			<ol style="font-size: 1.2rem; text-align: justify; line-height: 2.3;">
				<li>Attestation d’identité complète</li>
				<li>Attestation de bonne conduite, vie et mœurs</li>
				<li>Extrait du casier judiciaire</li>
				<li>Curriculum vitae</li>
				<li>Diplôme  et  /ou  certificat(s)  obtenu(s),  (certifié  conforme  à  l’original: Ministère de l’éducation), A1</li>
				<li>Frais d’étude du dossier =200.000FBu</li>
				<li>Lettre  de  demande d’inscription,préciser  le  tableau(TA:  Auditeur Indépendant,  TB:  Comptable  Indépendant,  TC:  Conseil  Fiscal,  TD: Comptable Salarié(adressée à Monsieur le Président du Conseil National de l’Ordre des Professionnels Comptables du Burundi)</li>

				<li>Attestation de service pour les salariésou attestation de service rendu.</li>
				<li>Carte de résidence pourles étrangers</li>
				<li>Etre inscrit dans l’Ordre du pays d’origine(Pourles étrangers)</li>
				<li>NIF pour les indépendant</li>
			</ol>
		</p>
		
	</div>
	

</div>

@include('site.footer')