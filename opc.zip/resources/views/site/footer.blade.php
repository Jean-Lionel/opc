        <div class="footer">
                                    <div class="footer-boxes">
                                        <div class="box-footer">
                                            <h5>LIENS UTILES</h5>
                                            <ul class="box-footer-text">
                                                <li><a href="">CPA CANADA</a></li>
                                                <li><a href="">FIDEF</a></li>
                                                <li><a href="">IFAC</a></li>
                                                <li><a href="">AAA</a></li>
                                            </ul>
                                        </div>

                                        <div class="box-footer">
                                            <h5>PLAN DU SITE</h5>
                                            <ul class="box-footer-text">
                                                <li><a href="">Devenir Expert-Comptable</a></li>
                                                <li><a href="">A propos de nous</a></li>
                                                <li><a href="">La profession</a></li>
                                            </ul>
                                        </div>
                                        <div class="box-footer">
                                            <h5>SUPPORT</h5>
                                            <ul class="box-footer-text">
                                                <li><a href=""> Devenir Membre</a></li>
                                                <li><a href="">Cabinets d'Experts</a></li>
                                                <li><a href="">Trouver un Expert Comptable</a></li>
                                                <li><a href="">Evenements</a></li>
                                            </ul>
                                        </div>
                                        <div class="box-footer">
                                            <h5>SUIVEZ NOUS</h5>
                                            <ul class="box-footer-text">
                                                <li><a href="">Facebook</a></li>
                                                <li><a href="">Twitter</a></li>
                                                <li><a href="">Pinterest</a></li>
                                                <li><a href="">Google Plus</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="footer-info-parent">
                                        <div class="footer-info">
                                            <img src="images/OPC1-1.png" alt="">
                                            <p>
                                                Développer et promouvoir la profession comptable du Burundi. -Défendre l'indépendance et l'honneur de la profession. -Introduire les réglés de transparence et de bonne gouvernance.
                                            </p>
                                            <form class="form-footer">
                                                <input type="email" class="input-footer" placeholder="Your email address">
                                                <input type="submit" class="submit-footer"  value="Subscribe">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script src="js/index.js"></script>
                        </body>
                        </html>