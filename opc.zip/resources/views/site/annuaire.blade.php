@include('site.header')

<div class="container">

	<div class="embed-responsive">

		<iframe src="{{ asset('/doc/annuaire%20telephonique.pdf') }}" width="100%" height="800px">
		
	</div>
	
</div>

@include('site.footer')