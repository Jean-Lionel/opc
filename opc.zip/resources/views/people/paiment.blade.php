@extends('layouts.base')

@section('content')

<div>
	<livewire:paiment-livewire/>
</div>


@endsection