@extends('layouts.base')

@section('content')

<div class="container-fluid">
	<livewire:cabinet-livewire />
</div>


@endsection