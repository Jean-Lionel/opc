@extends('layouts.base')

@section('content')

<div class="container-fluid">
	<livewire:person-livewire />
</div>


@endsection