@extends('layouts.base')

@section('content')

<div>
	<livewire:home-livewire />
</div>


@endsection