@extends('layouts.base')

@section('content')

<div>
	<livewire:person-livewire />
</div>


@endsection